
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author UCR
 */
public class Crud {

    ArrayList<Alumno> Alum = new ArrayList<>();
    Scanner e = new Scanner(System.in);
    
    /**
     * @author Luis
     * parte del codigo donde se aloja el menu de opciones
     */
    public void menu() {
        int opcion;

        System.out.println("menú de acciones ");
        System.out.println("1. registrar Alumnoo ");
        System.out.println("2. modificar Alumno ");
        System.out.println("3. mostrar lista de Alumnos");
        System.out.println("4. eliminar Alummno ");
        System.out.println("5. salir ");
        opcion = e.nextInt();
        e.nextLine();

        switch (opcion) {
            case 1:
                registerstudent();
                 menu();
                break;
            case 3:
                showStdents();
            menu();
                break;
              
                

        }

    }
    /**
     * @author Grace 
     * @author Luis 
     * metodo para registrar estudiantes
     */
    public void registerstudent() {
       int age;
       String fullName;
       String id;
       String mail;
       
        
        System.out.println("Datos del alumno");
        System.out.println("Digite el número de cédula del alumno");
        id = e.nextLine();
         for (Alumno alumno : Alum) {
            if (id.equals(alumno.getId())) {
                System.out.println("El alumno ya se encuentra registrado"); 
                menu();
            }
            
        }
        System.out.println("Digite la edad del alumno");
        age = e.nextInt();
        e.nextLine();
        System.out.println("Digite el nombre completo del alunno");
        fullName = e.nextLine();
        
        System.out.println("Digite el correo del alumno");
        mail = e.nextLine();
        
        
       
         Alum.add(new Alumno(age, fullName, id, mail));
        
    }
    
    public void updaterStudent (){
        
        
        
    }
    
    public void showStdents (){
        
        for (Alumno alumno : Alum) {
            System.out.println(alumno);
        }
        
    }
    
    public void preload (){
        
        Alum.add(new Alumno(19, "Mario Chacón", "324","Mc@gmail.com"));
        Alum.add(new Alumno(18, "Fernando Gómez", "768", "Lg@gmail.com"));
         Alum.add(new Alumno(18, "Grace Delgado", "123", "Gdqmail.com"));
          Alum.add(new Alumno(18, "Jesús Montero", "432", "Jm@gmail.com"));
    }

}

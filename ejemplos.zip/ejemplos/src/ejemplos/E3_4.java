/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos;

import java.util.Scanner;

/**
 *
 * @author UCR
 */
public class E3_4 {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);
        
        int tabla, resultado;
        System.out.println("Ingrese el valor de la tabla a calcular");
        tabla = leer.nextInt();
        
        for (int i = 0; i <= 10; i++) {
            
            
            resultado = tabla * i;
            System.out.println(tabla + " x " + i + " " + resultado);
            
        }
    }
}
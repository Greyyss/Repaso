/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos;

/**
 *
 * @author UCR
 */
public class E4_5 {

    public static void main(String[] args) {

        System.out.println("----VALORES DEL 1 AL 50----");

        for (int i = 1; i <= 50; i++) {
            System.out.println(i);
        }
        System.out.println("----VALORES DEL 50 AL 1----");

        for (int i = 50; i >= 1; i--) {
            System.out.println(i);
        }
        System.out.println("----VALORES DEL 50 AL 1 SUBIENDO DE 5----");

        for (int i = 50; i >= 1; i = i + 5) {
            System.out.println(i);
        }
        System.out.println("----VALORES DEL 50 AL 1 BAJANDO DE 5----");

        for (int i = 50; i >= 1; i = i - 5) {
            System.out.println(i);
        }
    }
}


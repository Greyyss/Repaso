/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos;

import java.util.Scanner;

/**
 *
 * @author UCR
 */
public class E2_1 {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);
        int valor_i, valor_f, cant_par = 0, cant_impar = 0, suma_par = 0, suma_impar = 0;

        System.out.println("Digite el valor a inicial");
        valor_i = leer.nextInt();

        System.out.println("Digite el valor final");
        valor_f = leer.nextInt();

        for (int i = valor_i; i < valor_f; i++) {

            if (i % 2 == 0) {
                System.out.println("PAR " + i);
                cant_par++;
                suma_par = suma_par + i;

            } else {
                System.out.println("IMPAR " + i);
                cant_impar++;
                suma_impar = suma_impar + i;
            }

        }
        System.out.println("Total pares: " + cant_par);
        System.out.println("Total impares: " + cant_impar);
        System.out.println("La suma de los pares es: " + suma_par);
        System.out.println("La suma de los impares es: " + suma_impar);
    }

}
